<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.1/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.js"></script>
</head>
<body>
    <?php

     ?>
<div class="card">
<?php if (session()->getFlashdata('error')) : ?>
        <div class="col-12">
            <div class="alert alert-warning">
                <?= session()->getFlashdata('error') ?>
            </div>
        </div>
    <?php endif; ?>

    <?php if (session()->getFlashdata('success')) : ?>
        <div class="col-12">
            <div class="alert alert-success">
                <?= session()->getFlashdata('success') ?>
            </div>
        </div>
    <?php endif; ?>
        <div class="card-body">
        <div style="text-align: center;">
        <a  href="<?php echo base_url() . 'createform' ?>"><button class="btn-primary" >Add</button></a>
        </div>
            <div class="table-responsive">
                <table id="manageTable" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($details as $k): ?>
                        <tr>
                            <td><?php echo $k['name'] ?></td>
                            <td><?php echo $k['email'] ?></td>
                            <td><?php if($k['status']==1){
                                  echo 'Active';
                            }
                            else{
                                echo 'Inactive';
                            } ?></td>
                            <td>
                           <a href="<?php echo base_url() .'editdata/'.$k['id'] ?>"><button>Edit</button></a>
                           <a href="<?php echo base_url() .'deletedata/'.$k['id'] ?>"><button>Delete</button></a>
                           </td>
                        </tr>
                        <?php endforeach ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>  
    <script>
    // var ajax_table = $('#manageTable').DataTable();
    $(document).ready(function() {
    $('.alert').delay(3000).fadeOut(300);
  });
    
</script>
</body>
</html>