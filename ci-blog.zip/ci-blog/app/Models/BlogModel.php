<?php 

 namespace App\Models;

 use CodeIgniter\Model;

 class BlogModel extends Model{

    protected $table = 'blog';
    protected $primaryKey = 'id';

    protected $allowedFields = [
        'name',
        'email',
        'status'
    ];

public function createdata1($data){
    return $this->insert($data);
}
public function getdata(){
    return $this->findAll();
}

public function getdataByid($id){
    return $this->where('id',$id)->first();
}

public function update1($id,$data){
    return $this->update($id,$data);
}

public function delete1($id){
    return $this->delete($id);
}
    
 }






?>