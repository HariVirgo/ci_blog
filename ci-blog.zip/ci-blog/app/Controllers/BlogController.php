<?php

namespace App\Controllers;

use App\Models\BlogModel;


class BlogController extends BaseController
{




    public function index()
    {
        $data = [];
        $blogmodel = new BlogModel();
        $data['details'] = $blogmodel->getdata();
        return view('list',$data);
    }


    public function create()
    {
        return view('create');
    }

    public function createdata()
    {
        $session = session();
        // print_r('test');
        // die;
        $data = [
            'name' => $this->request->getVar('username'),
            'email' => $this->request->getVar('email'),
            'status' => $this->request->getVar('status')
        ];
        $blogmodel = new BlogModel();
         $insert = $blogmodel->createdata1($data);
         if($insert){
            $session->setFlashdata('success', 'Category created');
            return redirect()->to('/');
        } else {
            $session->setFlashdata('error', 'Category not created');
            return redirect()->to('/');
        }
    }

    public function updateform($id){
        
        $blogmodel = new BlogModel();
        $data['updatedata'] = $blogmodel->getdataByid($id);
        return view('updateform',$data);
    }
    public function update(){
          $id=$this->request->getVar('id');
        $data = [
            'name' => $this->request->getVar('username'),
            'email' => $this->request->getVar('email'),
            'status' => $this->request->getVar('status')
        ];
        $blogmodel = new BlogModel();
         $update = $blogmodel->update1($id,$data);   
    }

    public function delete($id){
        $blogmodel = new BlogModel();
        $delete =  $blogmodel->delete1($id);


    }

}
